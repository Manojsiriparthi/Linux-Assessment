# Deployment

## Dev

```bash
cd envs/dev
# Replace the backend bucket placeholder first
terraform init
terraform validate
terraform plan
terraform apply
```

## Prod

```bash
cd envs/prod
# Replace the backend bucket placeholder first
terraform init
terraform validate
terraform plan
terraform apply
```

Destroy only when intentionally required:

```bash
terraform destroy
```

The instances use the default VPC in each target region. Ensure a default VPC and at least one subnet exist in every target region before applying.
