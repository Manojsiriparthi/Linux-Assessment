# Day 2 Task 1 - EC2

Self-contained Terraform environments. Enter `envs/dev` or `envs/prod` and run init, validate, plan and apply directly.

```bash
cd envs/dev
terraform init
terraform validate
terraform plan
terraform apply
```

The root configuration creates 8 EC2 instances across four regions: ap-south-1, us-east-1, eu-west-1 and ap-southeast-1. It covers t4g, t3, m6i, c6i and r6i families, ARM/x86 AMI selection, EC2 IAM instance profile, encrypted root volume, IMDSv2 and no SSH/RDP ingress by default.

AWS credentials are not hardcoded. The normal AWS credential chain is used; on EC2 this can come from the attached IAM role.

Before `terraform init`, replace `REPLACE_WITH_PIP_TERRAFORM_STATE_BUCKET` in the selected environment's `backend.tf` with your existing S3 state bucket.
