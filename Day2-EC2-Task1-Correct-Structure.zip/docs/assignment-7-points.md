# EC2 Assignment - 7 Points

1. Multi-region deployment: 8 EC2 instances across 4 AWS regions.
2. Instance families: t4g, t3, m6i, c6i and r6i.
3. ARM/x86 AMI selection using Amazon Linux 2023 SSM public parameters.
4. Least-privilege IAM role and EC2 instance profile attached to every instance.
5. Security: encrypted root volumes, IMDSv2 required, and no SSH/RDP ingress by default.
6. Separate dev and prod root configurations, each with its own S3 backend and tfvars.
7. Reusable `modules/ec2` and `modules/iam`, with explicit AWS provider declarations.
