terraform {
  backend "s3" {
    bucket       = "REPLACE_WITH_PIP_TERRAFORM_STATE_BUCKET"
    key          = "day2/ec2/dev/terraform.tfstate"
    region       = "ap-south-1"
    encrypt      = true
    use_lockfile = true
  }
}
