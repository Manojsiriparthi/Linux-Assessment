module "iam" {
  source = "../../modules/iam"
  providers = {
    aws = aws.ap_south_1
  }
  project     = var.project
  environment = var.environment
}

module "ap_south_1" {
  source = "../../modules/ec2"
  providers = { aws = aws.ap_south_1 }
  project = var.project
  environment = var.environment
  email = var.email
  region_label = "ap-south-1"
  iam_instance_profile_name = module.iam.instance_profile_name

  instances = [
    { name = "pip-${var.environment}-ap-south-1-t4g", instance_type = "t4g.micro", architecture = "arm64" },
    { name = "pip-${var.environment}-ap-south-1-t3",  instance_type = "t3.micro",  architecture = "x86_64" }
  ]
}

module "us_east_1" {
  source = "../../modules/ec2"
  providers = { aws = aws.us_east_1 }
  project = var.project
  environment = var.environment
  email = var.email
  region_label = "us-east-1"
  iam_instance_profile_name = module.iam.instance_profile_name

  instances = [
    { name = "pip-${var.environment}-us-east-1-m6i", instance_type = "m6i.large", architecture = "x86_64" },
    { name = "pip-${var.environment}-us-east-1-c6i", instance_type = "c6i.large", architecture = "x86_64" }
  ]
}

module "eu_west_1" {
  source = "../../modules/ec2"
  providers = { aws = aws.eu_west_1 }
  project = var.project
  environment = var.environment
  email = var.email
  region_label = "eu-west-1"
  iam_instance_profile_name = module.iam.instance_profile_name

  instances = [
    { name = "pip-${var.environment}-eu-west-1-r6i", instance_type = "r6i.large", architecture = "x86_64" },
    { name = "pip-${var.environment}-eu-west-1-t4g", instance_type = "t4g.micro", architecture = "arm64" }
  ]
}

module "ap_southeast_1" {
  source = "../../modules/ec2"
  providers = { aws = aws.ap_southeast_1 }
  project = var.project
  environment = var.environment
  email = var.email
  region_label = "ap-southeast-1"
  iam_instance_profile_name = module.iam.instance_profile_name

  instances = [
    { name = "pip-${var.environment}-ap-southeast-1-t3",  instance_type = "t3.micro",  architecture = "x86_64" },
    { name = "pip-${var.environment}-ap-southeast-1-t4g", instance_type = "t4g.micro", architecture = "arm64" }
  ]
}
