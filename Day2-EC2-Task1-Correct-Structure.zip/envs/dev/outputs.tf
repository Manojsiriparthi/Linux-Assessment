output "ec2_instances" {
  value = merge(
    module.ap_south_1.instances,
    module.us_east_1.instances,
    module.eu_west_1.instances,
    module.ap_southeast_1.instances
  )
}

output "iam_instance_profile" {
  value = module.iam.instance_profile_name
}
