terraform {
  required_providers {
    aws = {
      source = "hashicorp/aws"
    }
  }
}

data "aws_vpc" "default" {
  default = true
}

data "aws_subnets" "default" {
  filter {
    name   = "vpc-id"
    values = [data.aws_vpc.default.id]
  }
}

data "aws_ssm_parameter" "al2023_x86" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-x86_64"
}

data "aws_ssm_parameter" "al2023_arm64" {
  name = "/aws/service/ami-amazon-linux-latest/al2023-ami-kernel-default-arm64"
}

resource "aws_security_group" "ec2" {
  name        = "${var.project}-${var.environment}-${var.region_label}-ec2-sg"
  description = "EC2 security group with no inbound SSH/RDP"
  vpc_id      = data.aws_vpc.default.id

  egress {
    description = "Allow outbound traffic"
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  tags = {
    Name        = "${var.project}-${var.environment}-${var.region_label}-ec2-sg"
    Project     = var.project
    Environment = var.environment
    Email       = var.email
  }
}

resource "aws_instance" "this" {
  for_each = { for item in var.instances : item.name => item }

  ami = each.value.architecture == "arm64" ? data.aws_ssm_parameter.al2023_arm64.value : data.aws_ssm_parameter.al2023_x86.value
  instance_type = each.value.instance_type
  subnet_id = data.aws_subnets.default.ids[0]
  vpc_security_group_ids = [aws_security_group.ec2.id]
  iam_instance_profile = var.iam_instance_profile_name

  metadata_options {
    http_endpoint = "enabled"
    http_tokens   = "required"
  }

  root_block_device {
    encrypted = true
  }

  tags = {
    Name         = each.value.name
    Project      = var.project
    Environment  = var.environment
    Email        = var.email
    Region       = var.region_label
    Architecture = each.value.architecture
  }
}
