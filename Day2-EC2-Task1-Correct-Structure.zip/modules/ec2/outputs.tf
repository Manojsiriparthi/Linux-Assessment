output "instances" {
  value = {
    for name, instance in aws_instance.this : name => {
      id                = instance.id
      instance_type     = instance.instance_type
      availability_zone = instance.availability_zone
      private_ip        = instance.private_ip
      architecture      = instance.architecture
    }
  }
}

output "security_group_id" {
  value = aws_security_group.ec2.id
}
