variable "project" { type = string }
variable "environment" { type = string }
variable "email" { type = string }
variable "region_label" { type = string }

variable "instances" {
  type = list(object({
    name          = string
    instance_type = string
    architecture  = string
  }))
}

variable "iam_instance_profile_name" {
  type = string
}
