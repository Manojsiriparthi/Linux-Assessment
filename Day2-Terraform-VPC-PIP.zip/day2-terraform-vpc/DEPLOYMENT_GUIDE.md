# Day 2 Deployment Guide

## Validate dev

```bash
cd envs/dev
terraform fmt -recursive
terraform init
terraform validate
terraform plan -var-file=terraform.tfvars
```

Repeat the same commands under `envs/test` and `envs/prod`.

## Apply

Only apply after reviewing the plan:

```bash
terraform apply -var-file=terraform.tfvars
```

## Destroy lab resources

If you actually applied the stack and need to remove it:

```bash
terraform destroy -var-file=terraform.tfvars
```

**Warning:** `terraform destroy` deletes the resources managed by that environment.
