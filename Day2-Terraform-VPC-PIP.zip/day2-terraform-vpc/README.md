# Day 2 PIP – Terraform Modular Networking

This project creates a reusable AWS networking module and deploys it separately for **dev, test, and prod**.

## Architecture

Each environment creates:

- 1 VPC using a `/16` CIDR
- 3 public subnets using `/25`
- 3 private subnets using `/24`
- 1 Internet Gateway
- 3 NAT Gateways (one per AZ for redundancy)
- Public and private route tables
- Route-table associations
- Environment-specific tags

## Directory

```text
day2-terraform-vpc/
├── modules/
│   └── networking/
│       ├── main.tf
│       ├── variables.tf
│       └── outputs.tf
├── envs/
│   ├── dev/
│   ├── test/
│   └── prod/
├── docs/
│   └── Day2-VPC-Explanation.md
└── README.md
```

## Deploy one environment

```bash
cd envs/dev
terraform init
terraform fmt -recursive
terraform validate
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars
```

Repeat for `test` and `prod`.

> **Cost note:** NAT Gateways are billable resources. The configuration uses three NAT Gateways per environment to satisfy the high-availability design. For a low-cost lab, set `nat_gateway_count = 1` before applying.

## Important CIDR design

A `/16` VPC provides 65,536 IPv4 addresses (65,536 total addresses in the CIDR block). A `/24` has 256 addresses and a `/25` has 128 addresses. AWS reserves five IPv4 addresses in each subnet, so usable host capacity is lower than the raw CIDR count.

The three `/24` private subnets and three `/25` public subnets are intentionally separated by environment and AZ for easier routing, scaling, and troubleshooting.
