# Day 2 – Short Interview Answers

**Why did you use a Terraform module?**  
I used a reusable networking module so the same VPC and subnet logic can be deployed consistently across dev, test, and prod. Only environment-specific variables change.

**Why `/16` for the VPC?**  
A `/16` provides a large private address space and leaves room for future subnets and workloads. It avoids redesigning the network when the environment grows.

**Why `/24` private subnets?**  
A `/24` provides 256 addresses before AWS reservations, giving private application/data workloads reasonable room to scale.

**Why `/25` public subnets?**  
Public subnets in this design need fewer addresses, so `/25` provides a smaller allocation while conserving the overall VPC address space.

**Why three AZs?**  
Three AZs improve availability and fault tolerance because the network is not dependent on a single Availability Zone.

**Why NAT Gateway?**  
NAT Gateway allows private instances to make outbound Internet connections without exposing those instances directly to inbound Internet traffic.

**Why one NAT per AZ?**  
One NAT Gateway per AZ removes a single-AZ dependency and improves resilience, although it costs more than a single NAT Gateway.

**Why separate VPCs for dev, test and prod?**  
Separate VPCs provide isolation between environments and reduce the risk of test or development changes affecting production.

**Why terraform.tfvars?**  
It separates environment-specific values from reusable Terraform code, allowing the same module to be reused across environments.
