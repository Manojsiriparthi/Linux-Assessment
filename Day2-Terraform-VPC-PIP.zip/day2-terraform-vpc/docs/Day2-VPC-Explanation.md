# Day 2 PIP – Terraform Modular VPC Explanation

## Page 1 – Architecture and CIDR Design

### 1. Why use Terraform modules?

A Terraform module lets me define the networking architecture once and reuse it for multiple environments. Instead of writing separate VPC code for dev, test, and prod, all environments call the same `modules/networking` module and provide different variables.

This improves consistency, reduces duplicate code, and makes future changes easier.

```text
                    modules/networking
                    /       |        \
                  dev     test      prod
```

### 2. Why use a `/16` VPC?

A `/16` gives a large private IPv4 address space. It provides 65,536 addresses in the CIDR block, before AWS subnet reservations.

I selected `/16` because the requirement is a production-style multi-AZ network that may grow later. A larger VPC CIDR gives room for additional subnets, workloads, and future services without immediately redesigning the network.

Examples:

```text
Dev   → 10.10.0.0/16
Test  → 10.20.0.0/16
Prod  → 10.30.0.0/16
```

Using different VPC CIDRs also avoids overlap between these environments and makes future VPC peering or Transit Gateway connectivity easier.

### 3. Why use `/24` private subnets?

A `/24` contains 256 IPv4 addresses before AWS reserves five addresses. I use `/24` for private subnets because application and data-tier workloads can require more IP addresses as the environment grows.

Private subnets do not have a direct route to the Internet Gateway. Their outbound Internet access goes through NAT Gateway when required.

```text
Private-AZ1 → 10.x.10.0/24
Private-AZ2 → 10.x.11.0/24
Private-AZ3 → 10.x.12.0/24
```

### 4. Why use `/25` public subnets?

A `/25` contains 128 IPv4 addresses before AWS reservations. Public subnets generally need fewer addresses than large private application subnets in this design, so `/25` provides a smaller allocation while leaving most of the `/16` available for future subnet design.

```text
Public-AZ1 → 10.x.0.0/25
Public-AZ2 → 10.x.0.128/25
Public-AZ3 → 10.x.1.0/25
```

### 5. Why three Availability Zones?

Using three AZs improves fault tolerance. If one AZ has a problem, workloads in other AZs can continue operating.

The subnet design therefore follows:

```text
AZ1 → Public + Private
AZ2 → Public + Private
AZ3 → Public + Private
```

---

## Page 2 – NAT, Routing, Environments and Terraform Workflow

### 6. Why use NAT Gateway?

Private instances may need outbound Internet access for updates, package downloads, or external APIs, but they should not receive direct inbound Internet traffic.

A NAT Gateway provides outbound connectivity from private subnets while keeping the private instances private.

```text
Private EC2
    ↓
Private Route Table
    ↓
NAT Gateway
    ↓
Internet Gateway
    ↓
Internet
```

### 7. Why one NAT Gateway per AZ?

The high-availability design uses one NAT Gateway in each AZ. Each private subnet can use the NAT Gateway in the same AZ, reducing dependence on another AZ.

```text
AZ1: Private → NAT1
AZ2: Private → NAT2
AZ3: Private → NAT3
```

This improves fault tolerance but increases cost because NAT Gateways are billable. For a learning/lab environment, `nat_gateway_count = 1` can be used to reduce cost if the requirement permits it.

### 8. Why separate dev, test and prod?

Separate environments reduce the chance that development or testing changes will affect production. Each environment has its own VPC and CIDR range.

```text
Dev   → 10.10.0.0/16
Test  → 10.20.0.0/16
Prod  → 10.30.0.0/16
```

The same Terraform module is reused, but the `terraform.tfvars` file changes the environment-specific values.

### 9. Why use `terraform.tfvars`?

`terraform.tfvars` stores variable values separately from reusable Terraform code. The same module code can therefore be used with different environment values.

Example:

```bash
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars
```

### 10. Why use `terraform.tfvars.backup`?

The `.backup` file is only a backup copy of the environment variable file. It is not Terraform state and should not be treated as a state backup.

Terraform state files contain infrastructure state and should normally be stored securely using a remote backend such as S3 with appropriate locking/versioning rather than committed to Git.

### 11. Terraform workflow

Before applying changes, I use:

```bash
terraform fmt -recursive
terraform init
terraform validate
terraform plan -var-file=terraform.tfvars
terraform apply -var-file=terraform.tfvars
```

The important workflow is:

```text
Write code
   ↓
terraform fmt
   ↓
terraform init
   ↓
terraform validate
   ↓
terraform plan
   ↓
Review
   ↓
terraform apply
```

### 12. Day 2 implementation summary

I created a reusable Terraform networking module and used it for dev, test, and prod. Each environment has a `/16` VPC, three `/24` private subnets, three `/25` public subnets, an Internet Gateway, NAT Gateways, route tables, and environment-specific variables.

The design is modular, multi-AZ, reusable, and suitable for extending later with ALB, EC2, RDS, VPC endpoints, Flow Logs, security groups, and Network ACLs.

---

# Screenshot Evidence

## Terraform Directory

📸 **INSERT SCREENSHOT HERE**

## Terraform Plan – Dev

📸 **INSERT SCREENSHOT HERE**

## VPC in AWS Console

📸 **INSERT SCREENSHOT HERE**

## Subnets

📸 **INSERT SCREENSHOT HERE**

## NAT Gateways

📸 **INSERT SCREENSHOT HERE**

## Terraform Outputs

📸 **INSERT SCREENSHOT HERE**
