terraform {
  required_version = ">= 1.5.0"

  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = "~> 6.0"
    }
  }
}

provider "aws" {
  region = var.region

  default_tags {
    tags = {
      Project   = "Day2-PIP"
      ManagedBy = "Terraform"
      Environment = var.environment
    }
  }
}

module "networking" {
  source = "../../modules/networking"

  name                  = var.environment
  vpc_cidr              = var.vpc_cidr
  availability_zones    = var.availability_zones
  public_subnet_cidrs   = var.public_subnet_cidrs
  private_subnet_cidrs  = var.private_subnet_cidrs
  nat_gateway_count     = var.nat_gateway_count
  tags                  = var.tags
}
