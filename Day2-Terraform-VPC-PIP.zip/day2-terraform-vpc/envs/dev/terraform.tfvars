environment = "dev"
region = "ap-south-1"

vpc_cidr = "10.10.0.0/16"

availability_zones = [
  "ap-south-1a",
  "ap-south-1b",
  "ap-south-1c"
]

public_subnet_cidrs = [
  "10.10.0.0/25",
  "10.10.0.128/25",
  "10.10.1.0/25"
]

private_subnet_cidrs = [
  "10.10.10.0/24",
  "10.10.11.0/24",
  "10.10.12.0/24"
]

nat_gateway_count = 3

tags = {
  Owner = "DevOps"
  Purpose = "PIP-Day2"
}
