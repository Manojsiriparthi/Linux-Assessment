variable "environment" {
  description = "Environment name."
  type        = string
}

variable "region" {
  description = "AWS region."
  type        = string
}

variable "vpc_cidr" {
  description = "VPC CIDR."
  type        = string
}

variable "availability_zones" {
  description = "Three Availability Zones."
  type        = list(string)
}

variable "public_subnet_cidrs" {
  description = "Three public /25 subnets."
  type        = list(string)
}

variable "private_subnet_cidrs" {
  description = "Three private /24 subnets."
  type        = list(string)
}

variable "nat_gateway_count" {
  description = "NAT gateways; 3 gives one NAT per AZ."
  type        = number
}

variable "tags" {
  description = "Environment-specific tags."
  type        = map(string)
  default     = {}
}
